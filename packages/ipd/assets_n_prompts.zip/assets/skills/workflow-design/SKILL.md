---
name: workflow-design
description: Build a small IPD WorkflowDefinition from a TaskInput and selected ProcessSpec.
---

1. Read the complete TaskInput and ProcessSpec.
2. Split work by independently reviewable deliverables, not by model calls.
3. Add one execution node for each accountable work package and at least one independent review node for every controlled output.
4. Bind one participant per node in the first release. Use the `agents` array so later versions can add participants without changing node identity.
5. Give every execution node a unique output path below `outputs/<node_id>` in the shared Run workspace.
6. Let execution nodes consume only approved upstream submissions. Review nodes consume submitted candidates.
7. Define each criterion once, connect requirement coverage, and set explicit final outputs and required reviews.
8. Copy TaskInput and ProcessSpec requirement identifiers exactly; do not invent prefixes or aliases.
9. Every execution output must reference at least one registered mechanical criterion and at least one semantic criterion. Review targets reference semantic criteria only; Runtime evaluates mechanical criteria. Use only mechanical check IDs and exact parameter schemas listed in the available asset summary.
10. Validate the draft with `workflow_draft_validate`, make the smallest correction required by its Compiler diagnostics, and only then call `workflow_draft_submit`.
