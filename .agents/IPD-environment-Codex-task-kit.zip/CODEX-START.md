# Codex 开工指令

请先完整读取 `CODEX-IPD-ENVIRONMENT-IMPLEMENTATION.md`，并以 `references/IPD-environment-review.md` 作为已发现问题的背景。后者是固定于 c650e51 的历史审查，不代表最新实现已经失败或新方案已经验证。

在 Nephamaster/pi 最新仓库实施统一执行环境改造并提交 PR。先读取最新 AGENTS.md 和源码，完成任务书 M0 的基线与复现，再按 M1—M6 逐步编码、测试和提交，不要只回复设计建议。

第一版只实现一个完整 Docker/OCI Provider 和 code-node24、office-pptx 两个实际可用 Profile。统一文件、搜索、Bash、后台进程和成果导出；保留既有 Pi Session、模板、工作流、批准、返工和封存行为。不要只改 Bash；不要自动退回弱隔离；不要继承宿主秘密、降低标准或删除测试。

先用真实 Docker 和合成 fixture 验证，不调用付费模型或生产系统。每个阶段把已实现、已验证、阻塞、下一步记录到 `Checkpoint/IPD-environment.md`。上下文恢复后先读该记录和任务书，避免重新猜设计。

在独立分支形成可审查提交和 PR，不直接推 main，不自行合并。只 stage 本任务路径，遵守仓库测试及依赖规则。缺少 Docker/权限等条件时明确报告，允许保留 Draft PR；不得用 Mock 或 skip 宣称集成通过。

最终给出 PR、模块改动、配置迁移、保留行为、真实测试结果与仍未实现的能力。
