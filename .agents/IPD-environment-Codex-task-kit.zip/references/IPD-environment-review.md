# IPD 执行环境审查与优化建议

审查基线：`Nephamaster/pi@c650e512450a22400e3e5114e0ce0823a6e46e97`  
最新提交：`fix: canonicalize IPD sandbox deny paths`，2026-09-15。  
范围：已推送 main 中的环境、工具、文件权限、Skill、节点执行与提交边界，以及相关测试和提交记录。本轮没有修改远程仓库，没有发起 PR。

## 1. 结论

同意 CodeX 将 Environment 作为一等资源、为受控节点提供持续执行空间的方向；不同意把问题简单归结为“bwrap 根本不适合 Agent”或“换成 Docker 就解决了”。当前问题是把**依赖供给、宿主路径发现、权限翻译、进程生命周期和业务恢复**集中到了单次 Bash 包装与 Skill 脚本里，却没有共同的环境契约。

建议保留现有 IPD 治理、Pi Session、结构化提交、逐输出封存等基础。新增可替换的执行环境后端，统一承接节点的文件和命令操作。第一版只实现一个经过端到端验证的 OCI Provider、少量版本化环境 Profile，以及显式的旧 Provider 兼容模式。不要一开始同时自建容器集群、microVM、分布式服务和完整快照系统。

当前确实存在补丁化倾向，但不是所有近期修复都是坏补丁。输入封存隔离、取消、有限并发、完整批准与完成条件等修复是必要的运行不变量修正，应保留；值得收敛的是环境适配中不断依据具体机器、应用和错误字符串追加规则的方式。

## 2. 当前环境的真实工作方式

`PiNodeSessionFactory` 创建宿主侧 Pi Session，注入节点契约、当前轮次事实和锁定 Skill。普通文件工具仍在宿主执行，依靠 `node-file-scope.ts` 的工具调用钩子做权限检查。只有 `bash` 被替换成 `createNodeSandboxedBashTool()`。后者每次启动一个 sandbox-runtime CLI，并动态生成 Home 路径 deny 列表和临时目录。[C01–C04]

当前并非完全没有持久状态：节点输出目录和 `sandboxHome` 会跨命令保留。但每次命令的 `TMPDIR` 都不同，命令结束即删除；没有作为正式资源管理的长期环境、进程句柄或本地服务。因此，“Session 一直存在”和“完整执行环境一直存在”必须区分。[C01,C04]

## 3. 具体发现

### F01：关闭 Pi 会话环境信息，不等于隔离宿主环境变量【立即处理】

链路：`getShellEnv()` 展开 `process.env` → `resolveSpawnContext()` 仅删除少量 `PI_*` 会话字段 → IPD 的 `childEnv` 再次展开收到的 env，然后覆盖 HOME/TMP/XDG。[C01,C05,C06]

因此 `exposeSessionEnvironment: false` 并不是凭证过滤机制。若宿主进程存在模型/API/云服务密钥等环境变量，当前 IPD 启动边界会继续向下传递这些值。这里没有读取或验证任何真实凭证，也没有执行窃取；风险由变量传递代码直接支持。

措施：使用默认拒绝的环境变量 allowlist，按 Profile 注入 PATH、locale、代理和必要配置；业务凭证单独授权，模型密钥保留在模型服务一侧。不要默认传递任意 `NODE_OPTIONS`、`PYTHONPATH`、`LD_PRELOAD` 等宿主执行控制变量。合法的 profile-specific 变量由可信配置明确设置。

### F02：Bash 与文件工具不是同一套读取权限【立即处理】

文件工具按节点 allowlist 检查。Bash 只对 `homedir()` 下未授权的区域构造 deny，再加上明确的 mutable-output denies；没有将整个宿主文件系统转化为同等的 allowlist。授权根的含义因此依赖项目是否位于 Home 下。[C01,C02]

此外，`runtimeReadRoots()` 会根据可执行文件位置推断整个运行时根，并加入 sandbox CLI 所在的 `node_modules`。例如 `.local/bin/python` 推导为 `.local`，这比“允许运行 Python”大得多。动态增加 required command 可能同时扩大宿主可读范围，而不只是增加一个命令。

隔离探针验证了规则生成层的不一致：Home 之外的合成私有文件不在生成的 deny 内，却不能通过文件工具的 allowlist 判断。该验证不是 OS sandbox 穿透测试。

措施：新 Provider 从已验证镜像和显式输入挂载构造文件视图，而不是先暴露宿主再枚举隐藏部分；执行环境资产与业务输入权限分别建模。旧 Provider 的有限保证必须明确，不应对外宣称与 OCI 隔离等价。

### F03：统一了文件工具入口检查，但递归搜索与 denied 路径别名仍有缺口【立即处理】

当前 `read/grep/find/ls/write/edit` 均已纳入检查，不能再说这些工具完全没有 guard。但 `node-file-scope.ts` 先按字符串路径判断 denied root，再按 realpath 判断 allowed root；而 `grep.ts` 随后在宿主启动 rg，未把 denied 子树传入搜索过滤。[C02,C07]

当 `read_paths=["."]` 且 `outputs/peer` 被禁止时：

```text
read outputs/peer/private.txt → 拒绝
read alias/private.txt，其中 alias → outputs/peer → guard 允许

grep path="." → 根目录通过 guard → rg 进入被禁止的子目录
```

两条路径已用临时合成文件进行隔离复现；搜索部分确实调用了当前环境的 rg，但没有加载整个 Pi 工具链。

措施：所有实际文件访问、递归遍历、图片读取与搜索应共享同一个环境后端的授权视图。旧实现短期至少应在 canonical allow/deny 判断及递归过滤上补齐测试；只检查初始目录不是递归读取授权。不能把“输入参数经过检查”当成“所有被访问文件都已获授权”。

### F04：最新 denied-symlink 修复仍可能把明确允许的目录重新禁止【规则生成已复现】

最新 `canonicalDenyRoots()` 会将每个禁止路径 realpath 化并去掉重复祖先；但没有重新与允许路径协调。[C01]

```text
允许 /home/demo/project/workspace
/home/demo/workspace-alias -> /home/demo/project/workspace

枚举 Home：workspace-alias 不是指定允许路径，因此进入 deny
canonicalize deny：alias 变成 project/workspace
结果：明确允许的 workspace 本身进入 denyRead
```

这并不意味着符号链接规范化不该做。问题是先以字符串生成例外，再独立规范化 deny，缺少统一策略语义。当前回归测试只覆盖“denied link 指向已被禁止父目录内部”的成功情形，未覆盖 alias 指向 allowed target 的反例。[C08]

### F05：持久状态的归属与命令生命周期不完整【通用长程任务前置】

`sandboxHome` 由 `sessionDirectory/sandbox/participantId/home` 决定，没有 nodeId；同一 Run 的 Worker 为节点传入同一 sessionDirectory，而 Compiler 仅要求 participantId 在节点内部唯一。两个不同节点复用 participantId 时，可以落到同一个 sandboxHome。[C01,C03,C09]

与此同时，短路径临时目录每命令创建和清理，解决了某些 socket 路径过长问题，却没有提供长期服务所需的稳定运行目录、环境身份和进程管理。当前还重新实现了一套 child-process 取消/清理逻辑：异步准备后注册 abort listener，没有复查 signal 是否已经 aborted；native Pi Bash 已有前后检查和更完整的进程等待/跟踪。[C01,C05]

措施：以不可碰撞的 lease ID 管理环境，记录 Run/node/participant 与环境代际；持久 scratch/cache 与单次命令 tmp 分开。命令需要前台/后台状态、输出游标、停止及整个 lease 的取消回收。不要把 participant 显示名当成全局资源身份。

### F06：环境问题进入 Skill，并改变了应用行为【最明显的业务侧补丁】

PPT Skill 声称 `pptxgenjs`、React、sharp 等已预装，缺失后建议 npm 安装；声明的 required commands 只有 node/python3/soffice/pdftoppm。实际 `soffice.py` 发现 AF_UNIX 不可用时，会在临时目录编译 C shim，额外依赖 gcc 与编译环境，再用 `LD_PRELOAD` 改写 socket/listen/accept/close 行为；关闭特定 listener 时执行 `_exit(0)`。[C10,C11]

这说明环境知识分散在 frontmatter、正文假设、包装器和 C 代码里，无法从 Skill 声明可靠推导执行条件。`_exit(0)` 也不能独立证明转换产物已正确写出；它不是完整 IPC 语义，只是特定兼容措施。这里未证明一次具体生产故障由 shim 引起，也未断言作者意图。

措施：保留有意义的应用封装，如 LibreOffice 独立 user profile、受控 timeout 和产物校验；将工具安装、字体、IPC 能力与系统库纳入环境 Profile。新环境应运行软件正常支持的路径。特殊 shim 若暂时不可移除，应限于明确的 legacy Profile、构建时产生并验证，不能继续作为所有任务默认恢复手段。

### F07：缺失环境没有被平台正式分类，错误仍容易变成模型排障循环【立即收敛】

`requiredCommands` 当前主要用于推导可读目录；命令不存在时是 `continue`，并非 preparation failure。Worker 又通过错误文本正则决定是否重试。实际缺失 sandbox 的错误包含 `sandbox requires ...`，而配置错误规则匹配的是 `required by IPD`，隔离复现结果是 `transient/retryable`。[C01,C03]

还应区分两条错误路径：某些命令非零退出先成为工具错误返回模型，未必抛到 Worker；因此只完善 Worker 的正则不会解决 Agent 一直排查环境的现象。`report_node_blocked` 当前也把环境依赖与事实、权限等业务缺口放在一起，并要求先尝试合理恢复。[C03,C05]

措施：环境未就绪、依赖安装失败、权限拒绝、命令失败、进程超时、结果未知及业务缺口使用稳定类型和责任归属。已知平台失败由平台处理，不让模型编译 shim 或无限寻找路径；普通业务命令失败仍可反馈给 Agent 调试。重试不能通过改错误文案意外改变行为。

### F08：测试已经增加，但没有形成环境行为契约【必须补齐】

当前有 mock-spawn 单测和真实 Linux integration test。后者会因系统条件不满足而跳过，实际覆盖复制文件、Node/Python 版本、require(pptxgenjs)、pdftoppm 版本；没有完整的生成→LibreOffice转换→逐页渲染链，也没有跨命令服务、IPC、密钥隔离与取消测试。guard 仅检查 bwrap/rg/socat，也未完整声明测试自身依赖。[C08,C12]

这不是“没有写测试”，而是测试重心偏向验证当前补丁的结构，缺少不同工具对同一环境作出一致观察的验证。未来 Provider CI 应有必须执行、不能静默跳过的专用环境任务；一般开发机可以跳过，但报告必须显示跳过原因。

## 4. CodeX 方案应如何修正

### 4.1 保留的方向

Environment 是明确资源，工具操作与宿主分离，持续工作区、独立输入、Profile/镜像和预检均合理。OpenHands 公开文档已经提供 Docker/Process/Remote sandbox 与统一文件和命令操作的实例，可优先研究其资源与生命周期边界，而不是完整迁入其 Agent 系统。[E01,E02]

### 4.2 不把隔离原语当成环境管理器，也不把容器当成充分安全条件

Anthropic 自己使用 bwrap/Seatbelt 为 Agent Bash 提供文件和网络限制。因此“bwrap 天生不适合 Agent”过度概括。更准确的判断是：该项目在没有环境供给与生命周期层时，要求命令级安全包装承担了太多职责。[E03]

同理 Docker 的边界取决于 daemon 权限、挂载、命名空间、capabilities、seccomp、网络和内核。仅“不挂 Home/docker.sock”仍不完整。根据目标威胁模型选择 rootless/非特权用户、无 host PID/network/IPC、最小 capability、受控出网、资源限制及安全发布通道。声明的磁盘配额也须确认后端实际可执行，不能只写 `10Gi`。[E04]

允许隔离环境内部正常 Unix socket 是合理目标，但需正确处理文件系统 socket 与网络命名空间等边界，不能只添加名为 `private-ipc` 的标签。gVisor/Firecracker 是更强隔离选择，不负责自动装好业务依赖；gVisor 仍有兼容性边界，Firecracker 还需要 KVM 和相应生命周期设施。[E05,E06]

### 4.3 Compiler 静态校验与真实环境预检分开

不建议将拉镜像、启动容器、运行软件混进纯 Compiler。编译阶段解析可信 Profile、检查版本、能力和权限，产出锁定环境需求。Execution Preparation 在实际 Provider 上检查能力并形成证据；节点派发前确认 lease、输入挂载和服务 ready。

预检要检查能力链而非 `which`：Office 应用测试最小文件生成、转换、渲染、字体选择；代码任务检查锁文件安装、编译、测试、临时本地服务和取消。预检不能保证未知项目永不出现新依赖，所以仍需要受控的项目依赖配置路径。

### 4.4 基础环境与项目依赖分层

基础镜像提供系统库、运行时、通用工具和字体；项目根据锁文件在私有 workspace/venv/node_modules 中安装依赖。安装允许访问的源、生命周期脚本、凭证和缓存需受策略控制。不要每缺一个包就重建全新 Profile，也不要允许修改宿主或全局镜像。

Dev Containers 可复用环境声明、Features 和预构建理念，但导入的安装/生命周期脚本仍是待执行代码，不是天然可信配置。Bazel RE 可借鉴明确输入、执行条件及缓存理念，但不要将交互式、长驻服务的 Agent 环境强行变成全静态 action graph。[E07,E08]

### 4.5 不重命名所有工具，不建立平行 Prompt 系统

保留 `bash/read/write/edit/grep/find/ls` 的模型接口，让实现路由到同一 EnvironmentLease。Pi 已有 BashOperations、ReadOperations 接入点，但 GrepOperations 并没有替换实际 rg 进程，不能只注入两个回调就声称全部远程化。[C05,C07,C13]

可以增补必要的后台进程 start/status/logs/stop 与 env_describe；不必同时创造一套同义的 exec/fs/artifact 工具。受控 SaaS/API 工具可以保留宿主 broker 实现，但必须有独立、明确的授权策略，不假设容器会约束宿主 custom Tool。

### 4.6 提交不是释放环境；换 Profile 不是普通重试

候选提交后仍可能返工，因此不能立刻销毁环境。先明确 live/awaiting-review/blocked/cancelled/retired 的保留条件，以及何时可以回收昂贵进程而保留工作数据。

文件快照、进程内存快照、AgentSession/checkpointer 是三件事。E2B 的文件与内存持久化是其具体能力，不能假定任何 Docker Provider 的 `snapshot()` 都有同样语义。抽象应显式声明支持的持久化范围。[E09]

切换环境镜像、工具版本或策略可能改变构建和评审结果。应记录受控版本变更与需要重验的证据，而不是 Agent 请求后直接静默换 Profile，继续使用旧的冻结记录。

### 4.7 Review 只读约束针对产物，而不是禁止所有临时写入

编译代码、运行测试、启动临时数据库或渲染文件常常需要 scratch。可让独立验证环境只读挂载候选成果，在自己的私有 scratch 中工作，再提交证据；这是后续显式权限模型升级，不代表现在可以绕过 review 禁用 Bash 的规则。

同样，执行工作区与可发布输出应区分。代码生成需要 `.git`、依赖目录、缓存和构建目录，不应要求只有最终 output 目录可写。所有写入仍在隔离 lease 中，只有声明输出可进入 Runtime 发布流程。

## 5. 适合当前系统的最小目标结构

```text
IPD Compiler / Runtime
  冻结任务、职责、输入、环境引用、权限与质量标准
                ↓
Environment Resolver + Preparation
  可信 Profile / 镜像 digest / 依赖约束 / 真实探针
                ↓
Environment Lease（唯一身份、持续工作区、私有进程）
  ├── Pi 工具后端：文件 / Shell / 必要的进程管理
  ├── 只读 Task/Skill/精确 Submission 输入
  ├── 私有工作区、scratch、缓存、本地服务
  └── 显式网络与密钥策略
                ↓
受控输出导出 → Runtime 校验 / 哈希 / 独立封存 → Review
```

这里的 Environment Service 首版可以只是同进程接口/模块，不等于微服务。环境执行层应尽量不依赖 IPD 阶段或 PPT 概念；IPD 负责绑定，Pi 负责 Session，Provider 负责受控 I/O 与进程，ArtifactStore 负责成果身份与发布。将来需要更多调用方时再提取公共 package。

当前 SubmissionStore 直接在宿主路径上 copy/hash/rename；迁移远程环境必须加受控导出边界，不能继续把容器绝对路径当宿主路径。保留每输出单独封存以及复制后校验，只改变读取成果的来源。[C14]

## 6. 分批优化措施

### 第一批：停止扩散隐患

收紧环境变量转发；给环境缺失稳定错误类型；处理已确认的 path/alias/recursive guard 缺陷；将底层初始化失败明确报告而非推动模型排障。不要新增允许整个 Home、关闭 seccomp、宿主 Shell 或自动弱化 Provider 的通路。

### 第二批：只做一个完整的新后端

采用一个本地 OCI Provider，平台管理 `code-node24` 与 `office-pptx` 两种 Profile。先完成确定性 smoke tests，再接 Agent。锁定镜像 digest、依赖锁、架构和基础能力；使用稳定短虚拟路径。第一版无需 Kubernetes、动态生成镜像 DSL 或四种 Provider 同时落地。

### 第三批：迁移全部执行入口与产物交接

将文件工具、搜索、Bash、后台进程和输出导出接入同一 lease，防止“一半容器、一半宿主”。旧 node-file-scope 可承担过渡期检查，但不应永久成为第二份相互矛盾的权限策略。控制层工具仍通过 Runtime broker 管理可信状态。

### 第四批：退役重复逻辑并测量

将 host-runtime-root 推测、Home sibling-deny 和应用级 preload 例外限制在明确 legacy 后端，设置退出条件；不自动退回低安全后端。将 Skill 内容打包为不可变只读资产，避免每一次读取都重新遍历哈希；不要简单删除完整性验证。记录 cold/warm prepare、工具实际运行、服务 ready、产物导出、失败类别和排障模型轮次；确认瓶颈后再做预热池和缓存。

## 7. 验收矩阵

| 类别 | 必须验证的行为 |
|---|---|
| 环境供给 | 干净宿主只安装选定 Provider，也能运行已认证代码与 Office Profile；不是依赖开发机全局包。 |
| 预检 | 命令存在但库/字体/IPC不可用时，不进入耗时业务 Agent；错误给出精确 capability 与探针结果。 |
| 连续工作 | 前后多次工具调用看到相同文件与依赖；明确是否持久 Shell；后台进程可查询和终止。 |
| IPC/服务 | 私有 Unix socket、本地 HTTP 服务、需要的数据库/浏览器正常工作，同时不可访问宿主控制 socket。 |
| 一致权限 | read/grep/find/ls/bash 对授权根、denied 子树、symlink 的结果一致。 |
| 身份 | 两节点同 participantId、两个 Run 同 nodeId 也不能共享私有 HOME/tmp/cache。 |
| 密钥 | 宿主伪测试密钥不会进入执行环境、stdout、普通任务文件或模型上下文；只验证合成值。 |
| 依赖安装 | 允许的项目依赖在私有目录安装，宿主/其它节点不改变；未授权源与权限升级被拒绝。 |
| 取消 | 在 prepare、spawn、后台服务和产物导出时取消均能收口，不遗留在途子进程或迟到正式提交。 |
| 产物 | 返回码0但没有合法文件不得成功；发布的数据与校验数据相同，评审输入不可被后续修改。 |
| 返工 | 同一逻辑任务保留必要执行状态，输入版本变更可追溯，旧证据不会自动覆盖新结果。 |
| 覆盖 | 专用环境 CI 实际执行 smoke/regression，不以默认 skip 代替该平台支持声明。 |

## 8. 本轮复现与边界

本目录有六个隔离探针，结果见 `probe-results.json`。用真实临时目录/symlink 验证辅助算法，目录搜索调用真实 rg。所有文件都是合成数据，用完删除。没有访问用户主机、账号或生产系统。

1. `alias-denies-allowed-target`：禁止列表规范化后包含原允许目录。
2. `home-only-policy-gap`：Home 外路径没有同等 Bash deny，而 allowlist 判断拒绝。
3. `alias-bypasses-mutable-path-deny`：别名通过当前 guard。
4. `recursive-search-not-filtered`：根目录通过 guard，rg 进入合成 denied 子目录。
5. `command-presence-is-not-enforced`：找不到 required command 静默跳过；可执行根推测扩大范围。
6. `missing-sandbox-misclassified`：真实格式的缺失依赖错误被归为 transient。

运行环境为 Node 22.16.0；仓库要求 Node >=24。本轮没有安装完整仓库依赖、没有运行完整 Compiler/Vitest，也没有实际运行 bwrap、OCI 或 LibreOffice 转换。因此结果证明的是被指出的辅助算法与接口边界问题，不是完整安全渗透测试或新架构已经通过测试。实际业务失败中的字体、shim 或 IPC 的具体因果关系仍需完整工具日志验证。

## 9. 来源索引

所有 C 类源码固定于 `c650e512450a22400e3e5114e0ce0823a6e46e97`；Web 文档为此次检索的公开版本。仓库固定使用 sandbox-runtime 0.0.26，不能直接将最新上游 README 的新增参数视为该版本已支持。


- [C01] `packages/ipd/src/adapter/node-sandbox.ts`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/packages/ipd/src/adapter/node-sandbox.ts

- [C02] `packages/ipd/src/adapter/node-file-scope.ts`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/packages/ipd/src/adapter/node-file-scope.ts

- [C03] `packages/ipd/src/adapter/pi-node-worker.ts`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/packages/ipd/src/adapter/pi-node-worker.ts

- [C04] `packages/ipd/src/adapter/pi-node-session-factory.ts`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/packages/ipd/src/adapter/pi-node-session-factory.ts

- [C05] `packages/coding-agent/src/core/tools/bash.ts`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/packages/coding-agent/src/core/tools/bash.ts

- [C06] `packages/coding-agent/src/utils/shell.ts`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/packages/coding-agent/src/utils/shell.ts

- [C07] `packages/coding-agent/src/core/tools/grep.ts`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/packages/coding-agent/src/core/tools/grep.ts

- [C08] `packages/ipd/test/node-sandbox.test.ts`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/packages/ipd/test/node-sandbox.test.ts

- [C09] `packages/ipd/src/compiler/validate-workflow.ts`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/packages/ipd/src/compiler/validate-workflow.ts

- [C10] `.pi/skills/pptx/SKILL.md`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/.pi/skills/pptx/SKILL.md

- [C11] `.pi/skills/pptx/scripts/office/soffice.py`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/.pi/skills/pptx/scripts/office/soffice.py

- [C12] `packages/ipd/test/node-sandbox.integration.test.ts`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/packages/ipd/test/node-sandbox.integration.test.ts

- [C13] `packages/coding-agent/src/core/tools/read.ts`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/packages/coding-agent/src/core/tools/read.ts

- [C14] `packages/ipd/src/runtime/submission-store.ts`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/packages/ipd/src/runtime/submission-store.ts

- [C15] `packages/ipd/src/tool/default-ipd-extension.ts`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/packages/ipd/src/tool/default-ipd-extension.ts

- [C16] `packages/ipd/src/runtime/workflow-runtime.ts`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/packages/ipd/src/runtime/workflow-runtime.ts

- [C17] `packages/ipd/package.json`
  https://github.com/Nephamaster/pi/blob/c650e512450a22400e3e5114e0ce0823a6e46e97/packages/ipd/package.json

- [E01] OpenHands V1 Sandbox overview
  https://docs.openhands.dev/openhands/usage/sandboxes/overview

- [E02] OpenHands SDK Agent Server overview
  https://docs.openhands.dev/sdk/guides/agent-server/overview

- [E03] Anthropic: Claude Code sandboxing
  https://www.anthropic.com/engineering/claude-code-sandboxing

- [E04] Docker Engine security
  https://docs.docker.com/engine/security/

- [E05] gVisor security architecture
  https://gvisor.dev/docs/architecture_guide/intro/

- [E06] Firecracker official overview
  https://firecracker-microvm.github.io/

- [E07] Dev Container specification overview
  https://containers.dev/overview

- [E08] Bazel Remote Execution overview
  https://bazel.build/remote/rbe

- [E09] E2B sandbox persistence
  https://e2b.dev/docs/sandbox/persistence
