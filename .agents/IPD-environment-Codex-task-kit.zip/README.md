# IPD 环境改造：交给 Codex 的任务包

入口：`CODEX-START.md`。

完整实施设计：`CODEX-IPD-ENVIRONMENT-IMPLEMENTATION.md`，包含范围约束、源码核对、数据模型、Provider 生命周期、工具迁移、网络与依赖、预检、封存、M0—M6 里程碑、25 项测试矩阵及 PR 验收。

`references/` 保存已有审查与隔离探针。探针只复现辅助逻辑，不是完整仓库或真实 Docker 测试；实施者必须补充真正的 Provider 和 IPD 集成测试。

审查基线：`c650e512450a22400e3e5114e0ce0823a6e46e97`。本文中环境接口与配置是待实现设计，不是声称已存在的 API。开工时以最新远端、实际源码和最新 AGENTS.md 核对。

本包不含已实现补丁，也不表示代码或 PR 已完成。
