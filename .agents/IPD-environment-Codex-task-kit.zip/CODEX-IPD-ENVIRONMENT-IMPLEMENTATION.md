# Codex 实施任务书：IPD 统一执行环境与工具后端改造

## 0. 任务、依据与执行方式

**仓库：** `Nephamaster/pi`。本方案最近核对的 `main` 为 `c650e512450a22400e3e5114e0ce0823a6e46e97`（2026-09-15）。开始实施时必须重新读取远端分支和工作区状态；如果基线已变化，先核对相关改动，不覆盖更新代码。

**本次目标：** 将受控节点的环境供给、文件访问、命令执行、后台进程和成果导出，统一到有明确身份和生命周期的执行环境中。覆盖 PPT 和代码开发，不再把通用环境问题变成 `node-sandbox.ts` 中的新路径例外或业务 Skill 中的临时修复脚本。

**本次不是：** 推倒 IPD、重写 Pi AgentSession、放开多人节点、实现递归 IPD、修改阶段评审语义，或者建设容器集群。保留现有正确的任务输入、模板选择、工作流编译、质量门禁、返工、准出与最终交付行为。

本文是基于已有审查提出的**待实现设计**。`ExecutionProfile`、`EnvironmentLease`、新错误码、配置位置和接口名称属于本次设计建议，不代表仓库已经存在。实际工具签名、Schema 版本和扩展点必须先读源码确认，禁止根据本文猜 API。

工作方式：在一个功能分支上按本文 M0—M6 逐步实施，每阶段先运行对应测试，再继续下一阶段。每阶段形成可审查提交，最终形成一个完整功能 PR；不得把只有 Docker Bash 包装、尚未迁移文件工具和封存链的中间版本标为可用。用户已要求提交 PR，但不要直接向 `main` 推送，也不要自行合并。

---

## 1. 必须保持的行为与禁止事项

### 1.1 不变项

1. IPD 仍是入口；Runtime 仍是正式 Run、节点、批准和返工状态的唯一写入者。
2. Pi 仍负责 AgentSession、上下文组装、模型调用及原生工具协议，不新建平行 Prompt 或 Agent 循环。
3. 正常多轮执行、提交补正和质量返工继续使用原 Session。环境准备失败不得伪装成一个新 Agent 接着运行。
4. Workflow 和 Baseline 冻结后，任务、标准、员工、工具及已锁定执行条件不得被模型自行修改。
5. `submit_artifact` 只是候选提交；不能跳过实际文件校验、封存、机械检查与独立 Review。
6. 上游输入仍对应确切 Submission/输出版本；多输出提交只向节点提供其实际获准消费的输出。
7. 批准失效传播、定点返工、必需评审、最终完成条件和取消后的迟到提交拒绝继续有效。
8. 预置模板入口继续可用；无必填材料模板不能因环境改造而重新要求 `source-pack`。
9. 普通 Pi 会话的本地工具行为不改变。环境改造只作用于显式绑定了该后端的受控节点。
10. 原来可正常完成的任务，在完成明确的环境配置迁移后仍可完成；不得通过降低质量标准维持表面的通过率。

### 1.2 不允许的实现捷径

- 不允许容器失败后自动退回宿主 Shell、bwrap 或无隔离运行；旧后端只能由可信配置显式选择。
- 不挂载宿主根目录、整个 Home、整个 Run 目录、原始凭证目录或 Docker socket 给业务环境。
- 不使用 `--privileged`、host PID/network/IPC、`seccomp=unconfined` 等作为兼容性兜底。
- 不把 Docker 命令、宿主挂载路径、凭证或额外 capabilities 交给业务 Agent 任意填写。
- 不把 `required-commands` 当作扩大宿主可读目录的授权；不继续从 `.local/bin`、Conda、npm 安装路径猜权限。
- 不自动修改宿主 PATH、包安装、字体、系统库、daemon、系统服务或防火墙。
- 不继续让业务节点通过编译 shim、修改全局环境或反复查找宿主目录修复基础设施。
- 不把 `external_actions=true` 直接翻译成无限制公网访问。
- 不把只传 `HTTP_PROXY` 当成网络隔离，不把写了资源数字当成资源限制已执行。
- 不以吞掉错误、扩大重试次数、改变错误文案或删除断言让测试通过。
- 不同时实现 Kubernetes、Podman、gVisor、Firecracker、E2B、内存快照和动态镜像编排。

### 1.3 范围控制

本次至少交付：一个 Docker/OCI Provider、两个可验证 Profile、统一文件/命令后端、受管后台进程、真实预检、成果导出封存、类型化错误、旧模式显式保留、自动化回归和使用文档。

不交付但要留出清楚边界：多人共享环境、子 Run、跨主机灾后续跑、任意数据库 sidecar 编排、公开服务发布、完整内存恢复、通用依赖求解器。不要为未实现功能增加空方法或含糊的成功返回。

---

## 2. M0：核对源码，先锁定回归基线

先完整阅读 `AGENTS.md`、相关子目录规则、`CONTRIBUTING.md` 和 `packages/ipd` 的运行文档。遵守实际仓库的测试与提交约定；不要为了省事运行未经允许的全量端到端测试或访问真实模型 API。

重点阅读并画出以下真实调用链：

```text
IPD 入口 → Service → ControlPlane / 模板重绑 → Compiler → WorkflowRuntime
    → PiNodeWorker → PiNodeSessionFactory → Pi 工具
    → SubmissionStore → MechanicalChecker / Review → FinalSubmission
```

### 2.1 优先检查的现有文件

| 现有位置 | 本次核对重点 |
|---|---|
| `packages/ipd/src/adapter/node-sandbox.ts` | 命令级隔离、环境变量、路径推导、取消和清理 |
| `adapter/node-file-scope.ts` | canonical allow/deny、递归搜索、symlink |
| `adapter/pi-node-session-factory.ts` | 所有实际工具的创建、Skill、虚拟上下文、Session 关闭 |
| `adapter/pi-node-worker.ts`、`node-session-adapter.ts` | Session 身份、多轮复用、错误传播、取消 |
| `adapter/node-context.ts`、`structured-submissions.ts` | 模型看到的路径、输入版本与结构化提交 |
| `compiler/compiler.ts`、`validate-node-agent.ts`、`contracts/baseline.ts` | 冻结环境引用的接入位置 |
| `registry/asset-assembler.ts`、Skill 解析和哈希相关文件 | 资产信任、依赖声明、不可变 Skill |
| `runtime/workflow-runtime.ts`、`ipd-service.ts` | preparation、并发、阻塞、取消、资源释放 |
| `runtime/submission-store.ts`、`artifact/manifest.ts`、`runtime/final-submission.ts` | 宿主文件假设、复制校验、封存及交付 |
| `tool/default-ipd-extension.ts` | Provider 配置、缓存键、工具装配和关闭 |
| `packages/coding-agent/src/core/tools/` | 原生工具真实 operations 接口与隐含宿主 I/O |
| `.pi/skills/pptx/` | 隐含依赖、字体、LibreOffice wrapper 与 shim |

若文件已经移动，记录新位置，不为了匹配本文文件名重复建设旧模块。

### 2.2 开发前基线

记录起始 commit、Node/npm 版本、操作系统、Docker Engine/CLI、架构、cgroup、rootless 与否和已有测试结果。用 faux 模型或已有 Mock Worker 验证下列路径，后续必须继续通过：

- 单节点执行、并行、Fan-in、多个目标的 Review。
- 提交补正留在同 round；质量返工形成新 round、保留原 Session。
- 旧输入失效、联合 Review 的批准失效、定点返工与完成条件。
- 取消及迟到提交拒绝；既有可视化与快照仍可读取新增状态。
- 模板读取、重绑、编译；没有附件的合法 TaskInput。

已存在的基线失败单独登记，不通过删除测试或改动无关逻辑掩盖。

### 2.3 将已有审查转成回归测试

审查包中的六个探针只能作为可疑行为和合成案例，不能替代仓库真实回归测试。至少覆盖：宿主环境变量传递、Home 外权限差异、alias 指向 denied、allowed 目录被 canonical deny 反向覆盖、递归搜索未过滤、缺失 sandbox 被误分类。另加同 participantId 跨节点目录冲突和异步准备期间取消。

M0 产物：基线记录、实际模块映射、预期变更范围、已确认的复现测试。未完成此步骤，不开始大面积改写。

---

## 3. 目标结构与最小数据模型

### 3.1 分层

```text
IPD：任务/责任/输入/质量/状态权威
   │ 编译后的环境绑定与当前 round 授权
   ▼
Environment Manager：解析、预检、租约绑定、生命周期与限流
   │
   ├─ Pi Tool Backend：同名文件工具、Bash、少量进程工具
   ├─ Docker Provider：容器、文件、进程、网络和导出
   └─ Legacy Provider：显式选择、能力有限、不得自动降级
   │
   ▼
私有成果导出 → Runtime 校验/哈希/封存 → Review/准出
```

Environment Manager 首版是同进程模块，不是微服务。Provider 不依赖 ProcessSpec、PPT、ST 或 Gate 决策；IPD adapter 将业务身份和权限转换成 Provider 请求。

### 3.2 只新增必要对象

**ExecutionProfile：可信、版本化的环境配方。** 包含 ID/version、Provider 类型、实际锁定镜像身份和平台、能力及版本、默认环境变量、允许的网络/资源上限、可信探针及其版本、私有目录约定。Profile 来自打包资产或明确受信任的管理员配置；项目中的 `devcontainer.json`、Dockerfile、Skill 和用户文件不能未经授权就成为可信基础设施代码。

**EnvironmentBinding：冻结后的节点环境计划。** 包含节点/参与者、选定 Profile、镜像内容身份、有效能力与策略摘要、逻辑读写根、Profile/Skill/probe hash。不保存真实凭证，不让业务 Agent 修改。参与 Baseline 的身份或与 Baseline 强关联的不可变执行计划哈希。

**EnvironmentLease：实际运行实例。** 至少记录不可碰撞 leaseId、Run/node/participant 关联、Provider handle、环境代际、状态、镜像身份、创建时间和清理状态。leaseId 由系统生成，不直接使用 participantId 作为容器名或私有目录名。

**RoundBinding：当前工作轮次。** 保存 roundId、当前输入集合的摘要、租约绑定代际和允许操作。旧 round 的调用、进程句柄和导出请求不得在重绑之后继续生效。

**ProcessHandle：受管命令/服务句柄。** 包含命令 ID、所属 lease/round、状态、退出码/信号、日志游标与停止结果；不让模型通过任意 PID 管理别的环境。

不要再加一套与这些对象含义重复的 SandboxSession、ExecutionContext、WorkerWorkspace 等无实质职责差异的实体。

### 3.3 Profile 和 Workflow 的关系

Workflow 可以增加可选的 `environment_ref`，只引用注册 Profile 的 ID/version，不允许填任意 Docker 参数、宿主路径或任意镜像字符串。

旧模板没有该字段时，通过**可信配置声明的默认/匹配规则**解析。规则依据显式 Skill 环境需求和注册 Profile 能力，不通过任务标题是否包含“PPT”或节点名字猜环境。多候选无法确定时返回明确诊断，不能按目录顺序随意选择。

不要求用户为了这次重构重新生成所有旧模板。若需要升级 Schema，提供受控入口规范化和测试，保持未改动的旧模板可用于新 Run；不得在磁盘上偷偷改写旧模板或已冻结 Baseline。

兼容旧 `required-commands`：将其转换为最低的“命令存在且能运行”探针需求，不再转换成宿主目录读取权限。新增 `environment-requirements` 的字段、类型、版本匹配语义必须实现解析、校验、序列化和测试，不能只写进 SKILL 文档。

### 3.4 Compiler 保持静态

Compiler 可以检查注册引用、版本约束、能力覆盖、Profile 是否被允许、工具后端支持及权限交集；不得在编译、草稿 validate、submit 时拉镜像、启动容器、运行 Shell 或下载依赖。

有效权限来自管理员上限、Profile、AgentCard、节点契约的共同约束。未知或后端不支持的强制能力应拒绝；不能默默忽略。

环境准备和资源排队有独立的超时及诊断，不偷偷消耗现有业务 round 的全部时限；也不能因为尚未派发 Agent 就无限等待。

实际镜像必须预先注册为内容身份。对本机构建镜像允许使用真实 Docker image ID 加平台信息；已发布镜像记录实际 repo digest。不要为没有发布的本地镜像编造 registry digest，也不要用可漂移的 `latest` 作为冻结身份。

---

## 4. Provider 与生命周期契约

### 4.1 接口职责

以下是接口职责，不是要求照抄一套未经验证的类型声明。结合实际 Pi 签名定义类型，使用可区分的结果类型和错误，不使用 `any` 容纳所有后端差异。

| 能力 | 必须具备的语义 |
|---|---|
| `prepare` | 幂等地准备指定环境，支持取消；成功即满足承诺的能力和限制 |
| `bindRound` | 为现有 lease 绑定当前输入与操作代际；在可安全重绑的边界执行 |
| `exec` | 流式输出、显式 cwd/环境、退出码/信号、超时和取消 |
| `read/write/edit/search/list` | 同一虚拟文件系统及权限视图，支持二进制和图片读取 |
| `start/status/logs/stop` | 管理跨工具调用的进程，归属于 lease 与 round |
| `exportOutputs` | 输出私有且稳定的文件集合给 Runtime，不能自行批准或发布 |
| `describe` | 返回已承诺并实测的环境、目录、版本、限制；无密钥与宿主管理信息 |
| `dispose` | 幂等停止并清理本 lease 资源，可等待完成并报告失败 |

控制层负责授权，Provider 负责执行；二者均不得接受业务 Agent 传入的任意宿主 destination。

### 4.2 生命周期

```text
Profile 静态解析
  → 基础能力预检
  → 创建租约 preparing
  → 当前节点资源/输入绑定 ready
  → 工具执行 active
  → 提交边界 quiescing/exporting
  → 等待评审 idle
  → 同 Session + 同 lease 的下一 round / 返工
  → Run 终止或明确退休：disposing → disposed
```

租约不以 round 为单位重建。文件、依赖和必要工作数据在同节点多轮中保留；正常返工不得重启 AgentSession。一次工具调用结束不删除整个环境，候选提交后也不能立即销毁。

区分文件连续性、进程连续性和 Shell 连续性：本版 Bash 每次调用使用新的非交互 Shell；`cwd` 和 env 显式传入，不承诺上次 `export`/`cd` 自动继承。需要跨调用的服务使用 ProcessHandle，不要求 Agent 使用 `nohup ... &` 猜状态。

本地 IPC、本地 HTTP 服务在同一私有环境内正常运行，不等于允许访问宿主服务或公网。跨节点/Run 的服务默认不互通。

### 4.3 取消、超时和异常

每个可能等待的操作都接受 AbortSignal：拉取/准备、启动、探针、文件复制、命令、日志等待、导出和关闭。异步准备前后、spawn 前后必须检查取消，不能只增加一个 listener。

取消宿主 `docker exec` CLI 不等于容器内命令已经停止。必须根据实际 Provider 确认进程或容器内对应执行已停止；Run 级取消要最终关闭整个相关租约，不能只杀宿主客户端。

创建容器后回执丢失时，凭幂等请求 ID、唯一名称及可信 labels 查找实际资源；不要重复创建第二个。找不到或无法确认时报告 unknown outcome，等待受控核对，不盲重试。

Provider 退出、OOM、初始化失败与业务命令非零退出必须区分。通用异常不能全部变成 transient。

### 4.4 等待、回收与重启边界

等待 Review 时保留 lease 身份与工作数据。可暂停不需要运行的环境，但必须实测平台支持，并明确服务和网络的影响。

blocked 不等于可以随意销毁。保留与已有同 Run 恢复语义一致的资源；如现有版本不支持恢复，明确告诉用户状态和清理入口，不要凭空宣称能够自动恢复。

宿主进程重启后的完整 Agent 恢复不属于本次，但不能完全不管理遗留容器。记录项目身份、Run/lease 与 controller ownership；只清理能够确认属于本进程/项目且已失去合法 owner 的资源。不能执行全局 `docker rm`，不能只凭名称前缀杀别人的任务。无法确认的租约报告为待处理。

---

## 5. Docker Provider：第一个且唯一的新执行后端

### 5.1 平台与实现选择

优先支持 Linux/WSL 中可用的 Docker Engine、Linux OCI 镜像。初版不承诺 Windows 原生容器、所有 rootless 配置和 Podman CLI 完全兼容。

通过一个有类型的 Docker adapter 集中调用受信任的 Docker CLI，避免各模块各自拼接 Docker 命令。用 argv 调用，不经宿主 Shell 拼接。业务 Shell 字符串只在容器内执行。所有 stdout/stderr 流式、有界，所有管理调用有独立超时和取消处理。

需要官方 Engine API 才能正确解决的问题可局部使用已审查实现，但不要同时维护两套全功能客户端。更不能为追求零依赖自行编写不安全的 tar 解析器、TLS 或复杂网络代理。

### 5.2 容器安全基线

采用非特权用户；禁止 privileged 和宿主命名空间；去掉非必要 capabilities，使用 no-new-privileges 和经验证的默认/明确 seccomp 策略。镜像根文件系统只读，显式开放私有工作区、HOME、scratch/cache/tmp。

Docker 管理端点只在受信任控制层使用。业务环境不接触 daemon socket、DOCKER_CONFIG、镜像仓库凭证和模型凭证。对宿主 Docker 调用环境与传入容器环境使用两份独立配置，不能共用一份 `process.env`。

容器 UID/GID、卷所有权和 rootless 映射必须实测。不要用 `chmod -R 777` 或 `chown` 整个用户仓库处理权限。

资源上限至少包含可执行的内存、CPU、PID 和日志限制。Rootless 是否真正支持 cgroup 控制要通过能力检测及实测判断；不支持强制限制时返回明确不可用。磁盘硬配额只有后端真正支持才声明支持，否则区分软水位监控与硬配额，并拒绝依赖不可实现硬配额的 Profile。

### 5.3 私有工作目录

建议固定虚拟路径：

```text
/ipd/context/                 当前节点契约与任务投影，只读
/ipd/skills/<id>/<hash>/       锁定 Skill 快照，只读
/ipd/inputs/<binding>/        仅本轮已授权的精确输入，只读
/workspace/                   节点业务工作树，按节点写权限开放子目录
/scratch/                     私有构建、计算与验证临时空间
/cache/                       私有依赖缓存
/home/agent/                  私有 HOME/XDG 配置
/tmp/                         容器私有临时目录
```

这些是容器路径，不是将同名宿主目录挂入容器。不要将整个 `.pi/ipd/runs` 映射进去再靠 Prompt 让 Agent 自觉不读。

保留现有逻辑输出路径，例如 `outputs/<node-id>/...`：对应容器内 `/workspace/outputs/<node-id>/...`。Provider 负责在受控边界转换虚拟路径与逻辑路径；路径映射不是全局字符串替换。

私有 scratch 不属于最终成果。旧节点 `write_paths` 仍限制逻辑业务输出，不能借新环境暗中扩大对共享业务文件的权限。代码开发可以在获准的私有工作树或 scratch 中完成安装/构建，正式输出仍按冻结 output contract 导出。

### 5.4 输入物化与符号链接

TaskInput 的本地材料先进入可信、带哈希的只读物化层；目录材料必须定义快照范围，不能保持指向不断变化宿主目录的宽泛链接。远程链接需要通过已授权 broker 获取，不能被误当成本地 mount source。

基于本轮真实 InputBinding，仅物化所需 Submission 的所需 output。不能因为需要一个输出而映射整个 Submission 父目录，不能通过证据索引又泄露未授权的其他输出。

容器看到的是这份限定视图，`read/grep/find/ls/bash` 都在它上面工作。路径处理覆盖相对路径、绝对虚拟路径、`..`、不存在目标、symlink 与递归遍历；禁止通过 realpath 或复制过程逃离物化边界。

运行时不直接使用模型提供的宿主路径。实现中区分 HostPath、SandboxPath、逻辑 ArtifactPath 的责任，避免同一 string 在不同层被当成不同文件系统路径。

### 5.5 返工时更新输入

保持 lease 和 Session，但在受控轮次边界更新输入视图。可以用由宿主 broker 管理、容器只读的独立 input-view 实现，不要求热修改 Docker mount 配置。

更新前停止旧 round 的执行与可能保留旧文件句柄的子进程，冻结新的输入清单，再开放新 round。禁止在旧进程运行时边改输入边继续执行。保留私有项目文件和已安装依赖；需要重启的服务明确记录，不声称所有进程状态永远持续。

历史上下文中的旧路径不能重新成为当前授权输入。旧文件可能已被合法处理并留在 Agent 记忆/工作产物中，不能虚假承诺“抹除所有历史知识”；必须保证新调用不能重新读取已撤销的原始挂载，旧产物不能自动成为新批准。

---

## 6. Pi 工具接入：不能只迁移 Bash

### 6.1 保留模型接口

保留 `bash/read/write/edit/grep/find/ls` 名称、参数习惯与关键返回行为。优先复用 Pi 的 ToolDefinition、截断、图片呈现、diff、文件变更队列等功能，通过实际支持的 operations 接口替换 I/O。

必须逐工具检查是否仍有宿主调用。特别是当前 GrepOperations 并不接管实际 rg spawn；`find/ls`、MIME 判断、图片读取、完整日志路径和路径解析也需核对，不能只替换部分回调。

若 Pi 原生 hook 不完整，最小化补全执行接口并让默认本地行为不变；新增回归保护普通 Pi 会话。不要直接复制整个 read/edit/grep 实现进入 IPD 然后独立维护。

图片和二进制仍需可读，错误信息、长文本分页、日志截断仍要合理。宿主侧允许对已经受控取得的 Buffer 做可信处理，但不得根据容器路径回到宿主重新打开文件。

### 6.2 显式工具运行位置

把工具分清：

| 类别 | 运行位置与约束 |
|---|---|
| 文件、命令、搜索、进程 | 绑定 EnvironmentLease，不能访问宿主业务文件 |
| 已注册外部 API/SaaS 工具 | 独立授权的 broker；不能假定容器会约束宿主闭包 |
| `submit_artifact`、`submit_review`、Draft 工具 | IPD 控制层，维护既有正式提交语义 |

对 OCI 节点，不支持后端迁移的文件/命令型工具在准备阶段明确报错。不能让 `powershell` 或未知命令类 custom tool 静默用宿主执行。

外部 broker 工具只有在定义了数据/权限边界后才能继续使用。若工具捕获了宿主 cwd、Shell 或任意文件写入逻辑，不能因为工具名在 allowlist 里就认定安全。

### 6.3 最少新增工具

可以新增 `environment_describe` 和一组受管进程操作，用于启动服务、查看状态、分页日志和停止。具体名称统一一次即可，不创建多套同义接口。

不新增绕过 `submit_artifact` 的正式发布工具。不将 Docker 管理 API 暴露给 Agent。不为进程功能额外绑定更宽业务权限：是否允许执行仍由已有节点/员工工具授权决定。

### 6.4 控制层与 Review

ST/Designer 的资产查询和 Draft 操作继续在控制层；不要求每个纯元数据控制角色都先启动一个重型 Office 容器。

Review 必须读取相同字节的封存成果。保持当前工具限制：如果现有版本禁止 Review Bash，不在本次环境迁移中偷偷开放。需要编译/渲染/运行验证时，可用独立验证执行节点产生证据供 Review 消费。更强的 Reviewer 私有 scratch 和执行权限属于后续显式权限升级。

已在 OCI 模式中获准执行文件工具的节点，不得因为“只是 Reviewer”就偷偷使用宿主路径后门；可以使用同 Provider 的只读任务视图，镜像选择按实际需求而非生产者镜像机械继承。

---

## 7. 环境变量、网络与项目依赖

### 7.1 环境变量

容器和命令环境从空集合构建，只注入可信 Profile 与明确授权的变量。默认不传模型/API/云凭证、SSH agent、宿主 HOME、Docker 配置、任意 NODE_OPTIONS/PYTHONPATH/LD_PRELOAD。

合法的 NODE_PATH、字体路径、Python venv 等由 Profile 或受控项目安装设置，记录来源。不要使用名称黑名单代替 allowlist。日志与错误也要脱敏，测试使用合成秘密，不扫描或打印用户实际环境变量。

### 7.2 网络

默认无外部网络，但容器内 loopback 和私有 Unix IPC 可用。本地开发服务器只在 lease 内可见；本次不做默认向 LAN/公网发布端口。

对已有 `external_actions=false` 的节点，不因为换容器就允许 npm/pip 直接出网。可以使用预装依赖、离线包或经独立授权的依赖准备；否则明确报资源策略不满足。

需要联网的 Profile 使用真实可执行的 restricted-egress：只允许经可信网关/代理访问指定目的地，容器不能绕过代理直连。不能直接使用默认 bridge 网络然后仅设置 HTTP_PROXY。采用成熟组件并固定版本；不要临时自写一个未经测试的通用代理。

负面测试必须覆盖未授权域名、IP 直连、IPv6、宿主网关/局域网地址、云 metadata、重定向及绕过代理。DNS 也有通信能力；如果实现仍允许不受限解析或 DNS 外带，不得宣称完全受控出网，必须限制或明确不支持相应安全级别。

首次里程碑可以先完成 none；最终宣称支持“受限联网项目安装”前，egress 的正反向测试必须真实通过。未支持时拒绝请求，而不是降级到 public。

### 7.3 项目依赖不是新 Profile

基础镜像安装操作系统包、运行时、编译器、通用库与字体；具体项目依赖在私有工作区/venv/node_modules 中，按锁文件安装并记录锁文件哈希。

Agent 可以在已经授权的命令、依赖源和安装策略内完成正常项目开发，不必每增加一个库都请求切换 Profile。基础操作系统依赖缺失、需要提权或扩大网络时，才升级为环境需求问题。

安装脚本是可执行代码。默认安装不运行未授权 lifecycle scripts；确有必要时在沙箱中按明确批准范围执行并记录。不要把 npm --ignore-scripts 看成完整网络或安全策略。Python 的源码包构建同样会执行构建代码；优先使用经完整性校验的 wheel，需要源码构建时在明确授权的隔离 setup 中完成，不虚构一个适用于所有 Python 安装过程的“禁用脚本”开关。

缓存首版私有。共享缓存仅限经过完整性验证的不可变包内容；不共享任意节点可写的 node_modules、venv 或编译产物，避免串扰和污染。

---

## 8. 两个 Profile 与真实预检

### 8.1 `code-node24`

包含经过构建测试的 Node 24、包管理工具、Git、基础构建工具、必要的命令工具和证书。依赖脚本需要的 Python/编译器是否纳入由实际 smoke test 证明，不根据宿主有无决定。

基础 smoke test：创建小型项目，按锁文件准备依赖，执行构建/测试；启动本地 HTTP 服务，在后续工具调用中访问；验证私有 Unix socket；停止服务并确认进程退出。使用受控 fixture 和依赖源，不访问真实业务仓库凭证。

项目真实依赖安装与测试不是基础镜像探针的一部分，可在后续受控 setup 阶段执行，不必预检任意项目才承认 Node 能力。

### 8.2 `office-pptx`

包含实际 PPT Skill 需要的 Node/Python 包、LibreOffice、Poppler、基础 XML/图片依赖、fontconfig 和具有明确许可的中英文字体。逐项阅读 Skill 的 import/require 和脚本调用，不只照抄四个 required commands。

版本要锁定；不要凭空填写当前没有构建验证过的版本或 digest。构建记录应说明基础镜像、系统包、JS/Python 锁文件、字体来源及许可。镜像按 digest 锁定可以稳定使用已构建内容，但不要未经证明宣称构建完全 bit-for-bit 可复现。

真正的 smoke test：生成含中文、英文、图表和备注的最小 PPTX；正常调用 LibreOffice 使用独立 user profile 转 PDF；使用 Poppler 渲染；检查页数、非空图片、关键文本、字体实际选择和转换超时。仅 `soffice --version` 不算通过。

禁止下载或提交许可不明的商用字体。最终 PowerPoint 渲染与 LibreOffice 预览可能不同，Profile 只能声明已测字体与渲染环境，不能承诺所有接收方机器完全一致。

### 8.3 预检时机与开销

部署/显式初始化：构建或拉取可信镜像、运行完整 Profile smoke，保存探针版本及结果。

Run 准备：静态 Workflow 成立后，在任何业务生产节点启动前，检查本 Run 全部必要 Profile 的基础能力与可用性。相同 Profile/镜像/平台/探针版本复用有效结果，不为每个节点重跑整套 Office 转换。

节点派发：检查实际 lease、用户/目录权限、输入视图、资源限制和必要服务 ready。基础能力验证不能替代当前实例检查。

缓存键至少覆盖 image ID/digest、平台、Provider/策略版本、探针 hash 与影响结果的配置。先保证正确，再做缓存；失败缓存不能永久阻止已修复环境。

---

## 9. 成果导出和封存：保留正确语义，切换数据来源

### 9.1 发布链不变

```text
Agent submit_artifact 候选
   → Runtime 核对输出声明与当前 round
   → Provider 导出稳定文件集合到私有 staging
   → 宿主可信侧校验路径、大小、文件类型、内容 hash
   → SubmissionStore 按输出独立封存
   → 原有机械检查、Review、批准与最终投影
```

Agent 不能指定任意宿主导出路径，不能请求整个容器文件系统导出。只处理声明 output 的声明文件，不顺手导出 HOME/cache/env/secret。

### 9.2 必须解决发布期间的并发写入

提交时禁止新的工作 I/O，等待本轮在途工具结束，再进入稳定导出边界。后台进程不能在复制中继续修改待发布文件。

Docker 初版优先验证“暂停整个任务容器＋经 daemon/独立只读导出通道读取”的实现。**不能在暂停后又依赖 `docker exec tar` 完成导出**。若采用文件卷和独立 exporter，必须保证只有原租约是写者、exporter 只读，且实际测试暂停时仍能完整读取。

若目标平台不支持所选一致性方案，明确返回 capability unavailable；不要退化为一边运行一边盲拷贝。冻结进程得到的是稳定文件视图，不自动代表数据库事务或应用缓存已刷盘；应用须先完成自身的 flush/关闭/导出要求，再提交成果。

导出失败或取消：清理 staging，正确恢复或关闭环境；失败 cleanup 要保留可见诊断，不能掩盖原错误或产生永远挂起 Promise。

### 9.3 信任的是导出的字节，不是环境自报的 hash

容器内计算的 manifest/hash 可作为辅助，不是最终信任根。可信侧对实际取得的字节重新计算 hash，保证校验与封存的是同一批数据。

若使用 archive 通道，不允许无过滤解压到宿主：拒绝绝对路径、`..`、路径重复/覆盖、越界 symlink/hardlink、设备、socket/FIFO、不合理文件数量/体积等。默认导出常规文件及目录；源码中确需保留的内部 symlink 要有明确安全规则和测试，不能简单全局 follow-links。

复制前后检验、逐输出隔离、取消检查和最终原子登记应保持。不要使用“容器返回 exit 0”代替现有 Artifact 验证。

在代码接入上，将 SubmissionStore 的成果源从硬编码 `run.workspace` 抽离成可信 SourceView/源目录参数：旧后端来自受控工作区，新后端来自已经校验的私有 staging。逻辑 output/path_prefix 校验保持不变；不要为了兼容又把容器成果同步到可变共享 workspace，制造两份互相覆盖的权威成果。

### 9.4 兼容原输出协议

保持 `submit_artifact` 的逻辑文件路径与 output ID；通过统一映射把容器路径变成逻辑 ArtifactPath，禁止在任意自然语言文本上做路径替换。

证据中的路径、日志和当前输入索引应提供可用的虚拟路径或 Artifact 引用，不泄露无关宿主绝对目录，也不能返回模型根本无法读到的宿主临时文件。

同一 Submission ID 同内容重试应得到同一结果；不同内容冲突应拒绝。导出及登记的幂等判断覆盖实际文件 hash，不因候选文字相同而接受已经变化的字节。

---

## 10. 类型化错误与模型交互责任

建立本次环境层的小型、稳定错误模型，至少包含 `code/layer/retryable/details`，必要时包含 `operationId` 和 `outcome`。只映射到现有 Runtime 状态，不为每个错误增加一套平行状态机。

| 错误类别（建议命名） | 行为 |
|---|---|
| `environment_unavailable` | Docker/镜像/基础能力不可用，准备失败；不启动业务模型轮次 |
| `profile_incompatible` | 显式环境需求不满足，返回配置诊断，不试着运行 |
| `policy_denied` | 保留拒绝和合法替代路径，不自动扩权或换后端 |
| `dependency_setup_failed` | 区分缺包、锁文件、允许源、脚本；允许范围内可以有限修复 |
| `command_failed` | 普通代码/测试问题反馈 Agent，不重建环境 |
| `process_timeout` | 确认目标执行停止，记录日志和退出状态 |
| `environment_lost` | 不谎称原环境连续；拒绝旧 round 提交，报告恢复边界 |
| `cancelled` | 关闭/停止对应资源，禁止后续提交 |
| `external_outcome_unknown` | 不盲重放可能已发生的动作，先查询/核对 |

环境失败可能先成为 Pi 工具错误、再返回给模型，而非直接抛到 Worker。需覆盖两条路径：对已经确定的 Provider 致命失败，在受控边界保留原始错误并终止受影响派发；普通命令非零仍留给 Agent 调试。不要让模型反复调用同一个已经失效的环境。

`report_node_blocked` 继续用于真实未满足条件，但不再要求 Agent 先尝试修复宿主基础设施。专业 Skill 说明已承诺的环境与合法恢复动作；环境信息由 Runtime 注入，不依赖模型记住一段 README。

---

## 11. 旧实现、Skill 和重复代码如何收敛

旧 sandbox-runtime Provider 仅保留为明确选项，如 `legacy-srt`，标明能力与保证不同。新配置显式选 OCI 后，任何失败都不得自动选择旧模式。

短期修复已证实的旧 guard、身份、环境变量与取消问题；不再给它添加 PPT/字体/Conda 等专用路径分支。不能声称有限 legacy 模式达到完整 OCI 隔离等级。

新的 OCI 路径不调用 Home sibling-deny、runtime executable-root 推测和应用级 LD_PRELOAD 修补链。稳定后把这些代码限定在 legacy 模块，确保只有一条明确入口。

PPT Skill 保留制作方法、独立 LibreOffice user profile、超时、输出验证和视觉 QA。删除或改写未经运行事实支持的“所有环境都预装了 X”；需求写入结构化环境声明。正常 OCI 路径不再动态编译 socket shim。legacy 若仍依赖该能力，显式保留与测试，不偷删用户已有功能，也不把未认证 shim 带回默认路径。

锁定 Skill 在准备时复制成内容寻址、只读快照，验证复制后的 hash；Session 的 Skill location 与工具看到的位置一致。源 Skill 后续变化不能改变当前 Run 的锁定字节。以此消除每次 read/bash 重算整个目录的开销，而不是直接移除完整性检查。

不要顺手重写所有 Prompt、AgentCard、ProcessSpec 或视觉前端。只更新本次环境能力、路径、失败责任和配置接入所需的文本。

---

## 12. 建议模块落点

以下是职责划分，不是强制每项一个文件；如果当前仓库已有合适模块，应直接扩展。不要建立只有一行转发的 Manager/Service/Facade 层。

```text
packages/ipd/src/environment/
  contracts.ts         Profile、binding、lease、process、errors
  profiles.ts          可信 Profile 读取、选择与静态解析
  manager.ts           prepare/bind/生命周期/并发与指标
  docker-provider.ts   唯一新 Provider，调用集中 Docker adapter
  paths.ts             虚拟路径、输入物化、导出路径边界
  tool-backend.ts      Pi operations 与受管进程工具
  ...                  仅在职责或测试需要时继续拆分

packages/ipd/environments/
  code-node24/         Dockerfile、锁文件、probe/fixtures
  office-pptx/         Dockerfile、锁文件、probe/fixtures
  ...                  真实构建/注册工具与公共基础部分
```

具体接入：`PiNodeSessionFactory` 接收环境后端而不是硬编码 Bash wrapper；`PiNodeWorker` 绑定 lease/round 与保留原 Session；`WorkflowRuntime/IpdService` 负责调用准备/取消/释放；`SubmissionStore` 从可信 staging 接收数据；`default-ipd-extension.ts` 负责可信配置和 Provider 注入，不包含 Docker 命令实现。

`packages/coding-agent` 只做确有必要的底层工具 hook 补全，默认本地路径必须有回归保护。不要把业务 Profile 概念污染普通 Pi 工具。

新增依赖须说明解决的问题、版本和使用范围。Docker/Office 体积放在独立镜像构建，不放入 npm 安装 lifecycle；加载 IPD 包或运行普通 Pi 不应自动下载镜像或安装 LibreOffice。

---

## 13. 里程碑与每阶段退出条件

### M0：基线与复现

完成第 2 节；把审查发现升级成仓库实际回归测试。记录当前行为与不支持项，不开始无边界重写。

### M1：执行契约与最小安全修复

完成类型化环境错误、变量 allowlist、身份及取消缺陷修复；引入 Profile/binding 和后端注入点。Compiler 保持静态，旧工具默认行为有保护。

退出条件：已有行为回归通过，静态解析可拒绝不支持的环境/工具；没有 OCI 失败自动 fallback。

### M2：脱离 LLM 跑通真实 Docker 环境

实现 prepare、命令/文件操作、私有 IPC、后台进程、取消、清理和两个 Profile 的 smoke。此阶段不需要消耗任何模型 token。

退出条件：同一 lease 多次 exec/文件操作一致；真实 PPT 转换/渲染通过；Node 项目构建/测试/本地服务通过；秘密隔离和资源策略有实际证据。不能用 mock Docker 代替此阶段。

### M3：统一 Pi 工具与上下文路径

接入全部文件、搜索、图片、Bash、日志和过程工具。处理自定义工具与控制工具的运行位置。让两类节点通过实际 Pi ToolDefinition 使用租约，而非只调用 Provider 单元 API。

退出条件：工具读写同一字节/同一目录；宿主文件后门不可用；普通 Pi 工具测试仍通过；旧业务契约及无材料模板不改变。

### M4：成果封存与返工生命周期闭环

实现稳定导出、可信校验、原有 Submission/Gate 接入；处理取消、重复回执、上游重绑和旧 round fencing。

退出条件：faux Session 完成并行执行→提交→Review 打回→原 Session/lease 返工→新版本通过→最终交付；联合评审批准失效和必需评审规则仍成立。

### M5：配置迁移与去除业务特例

完成初始化、Profile 选择、默认模式说明、legacy 显式选择、Skill 需求与 readonly 快照、必要的环境状态可视化。清理不再使用的重复实现，不动无关资产。

退出条件：用户按文档在干净环境部署，只需配置/构建 Profile 而无需修宿主包；旧模板能正常选择与重新编译，缺少配置有准确错误；import IPD 不产生安装副作用。

### M6：集成 CI、性能记录与 PR

跑完整相关测试、真实 Provider CI 和性能测量。review 最终 diff，只包含本次改动；补配置示例、迁移、限制、证据和回滚说明，创建 PR。

退出条件：第 14—16 节完成。若环境缺少 Docker，允许提交 Draft PR 或实现中间成果并明确阻塞，但不得标记 Provider 已通过，也不得把跳过的 integration 当作成功。

---

## 14. 测试与回归矩阵

至少形成四层测试：纯契约/逻辑测试、真实 Provider 测试、Pi 工具后端测试、faux Agent 的 IPD 全链路测试。测试尽量复用项目已有 fixture 和 worker，不需要真实用户凭证或付费模型。

| ID | 场景 | 必须断言 |
|---|---|---|
| E01 | 宿主放置合成 API 密钥/NODE_OPTIONS | 节点 env、文件和普通日志中没有该值 |
| E02 | 外部路径、`..`、alias、symlink、递归搜索 | 同一授权视图，无工具切换绕过 |
| E03 | allowed 目标另有未授权别名 | 不把明确 allowed 目录错误加入 deny |
| E04 | 两节点同 participantId / 两 Run 同 nodeId | lease、HOME/tmp/cache、进程与成果隔离 |
| E05 | 连续 Bash/文件调用 | 同一环境与文件状态；不假称持久 Shell |
| E06 | 后台 HTTP 服务/Unix socket | 后续调用可用；跨 lease 和宿主不可访问 |
| E07 | 准备前/中/后取消、spawn 窗口取消 | 不启动新业务工作，已创建资源正确清理 |
| E08 | 命令/服务运行、日志读取和导出取消 | 进程确实停止，无合法迟到提交 |
| E09 | 只存在命令，模块/字体/IPC 缺失 | 真实探针失败，业务模型未启动 |
| E10 | 合成代码项目 | 锁文件安装、构建、测试、服务、修改后重测成功 |
| E11 | 最小 PPTX | 生成、正常转换、渲染、文本/字体/非空图像验证成功 |
| E12 | none / restricted-egress | 正向允许源可用；负向公网、内网、直连和代理绕过被拒绝 |
| E13 | 默认包安装与 lifecycle 脚本 | 未授权脚本不运行，允许安装不污染宿主或其他 lease |
| E14 | 一个 Submission 两个输出，下游只绑 X | Y 和完整索引不因挂载父目录而可见 |
| E15 | 输出越界、symlink/hardlink、异常 archive | 拒绝越界，宿主 staging 外不改变 |
| E16 | 返回码 0 但产物不存在/损坏 | 不形成成功 Submission |
| E17 | 发布时后台进程持续写入 | 被稳定导出机制制止或明确拒绝，无未验证的混合版本 |
| E18 | 相同 operation/Submission 重试 | 内容相同幂等；不同内容拒绝 |
| E19 | 返工与上游版本变化 | 原 Session、必要工作数据保留；输入代际正确，旧审批不复活 |
| E20 | Provider 丢失/未知执行结果 | 不无条件 transient，不盲重放副作用 |
| E21 | Run 完成、取消、失败、宿主关闭 | cleanup 可等待；不会误删其他任务资源 |
| E22 | cgroup/配额不支持 | 声明与实际一致；强制能力不足时拒绝 |
| E23 | 普通 Pi 非 IPD 会话 | 工具参数、编辑、图片、截断与本地行为回归通过 |
| E24 | 旧模板/无附件任务/状态看板 | 模板兼容，质量标准不变，新环境错误可观察 |
| E25 | 多 Run 竞争、生产者等待 Review 保留租约 | 下游评审有准入空间或准备期拒绝，无资源互等死锁 |

测试不能只检查 Docker argv 或 JSON 里写了 `readOnly=true`。涉及隔离、取消、IPC、配额和导出的用例，要验证实际行为。

本地无 Docker 可以明确 skip；专用 Docker CI job 应在环境缺失时失败，不许静默 skip。CI 不访问真实模型或生产 SaaS，也不向测试任务提供仓库写入凭证。

新增回归如果当前会失败，应先作为复现执行并记录，再完成修复变绿；不要提交一个声称完成却仍带预期失败的最终 PR。

---

## 15. 性能与代码维护要求

先记录基线，再比较新实现。分别报告环境冷/热准备、每次工具 I/O、命令真实执行、服务启动、Skill 校验、成果导出、总模型调用与环境错误诱发的额外轮次。不要承诺未经测量的固定提速倍数。

结构上应验证：同一节点多次工具调用只创建一个 lease；不每次 Bash 拉镜像/装依赖/重建目录；不每次 read 重新哈希整个 Skill；不为看板读取重复跑探针；关闭状态下资源不会持续积累。

资源准入必须以实际环境生命周期计费：限制并行准备、活跃 lease 和总资源，不仅限制正在运行的节点函数。等待 Review 仍占内存，不能当成零资源；暂停容器也不能被当成已释放内存。容量不足时排队或报告，不能提前销毁仍可能返工的环境来冒充满足连续性。

必须防止“生产者保留环境占满容量，Reviewer 永远无法启动”的资源死锁。首版可以采用保守的 Run 资源预留，覆盖需要同时存续的环境以及下游评审启动空间；无法满足时在准备期明确拒绝。不要先启动半个任务再无限排队，也不必为优化这项预留立即实现复杂的全局调度器。

第一版不做热池和跨 Run 可写缓存。确认冷启动是瓶颈后再添加，避免把隔离问题转移到缓存污染和回收复杂度。

维护标准：每个模块职责明确，不按 PPT、代码、浏览器分别复制执行器；仅 Profile/probe/setup 具有应用特定内容。旧路径在一个明确 backend 中，避免 `if (provider)` 散布整个 Runtime、Compiler 和 Prompt。

允许为安全 archive 处理等必要问题新增小型、固定版本依赖；不以零依赖为理由手写脆弱实现。不要通过强制单文件行数指标把相关逻辑切碎，但一份文件同时管理 schema、Docker、Prompt、鉴权和封存时应重新拆分。

---

## 16. 文档、提交、PR 和完成判定

### 16.1 文档必须回答

- 支持的宿主/引擎/架构和能力限制；rootless 与 rootful 的实际测试情况。
- 如何显式初始化/构建/注册两个 Profile；如何离线或受限网络准备依赖。
- 普通 Pi 不用容器时是否受影响；旧 Workflow 怎么选择默认 Profile。
- legacy 如何显式选择，为什么不自动 fallback。
- 服务、输入、scratch、缓存、最终 output 的路径和权限。
- 取消、等待 Review、返工、环境丢失与宿主重启的真实语义。
- 环境升级、Profile 变化、镜像更新如何形成新执行身份。
- 已实现与尚未实现的区别，尤其不要宣称支持完整快照/灾后续跑。

仓库运行产生的 sessions、telemetry、容器镜像、字体二进制、真实日志、凭证、生成 PPT 不进入源码提交；必要样例均为小型合成 fixture。重要设计、排障结论、已完成和阻塞项写入 `Checkpoint/IPD-environment.md`，不要记录每一次普通编辑。

### 16.2 测试与提交

按最新 `AGENTS.md` 执行依赖安装、`npm run check` 及对应测试。不要运行未经允许的 paid/e2e suites，不跳过 pre-commit。依赖和 lockfile 变更按仓库约定单独说明，必要授权不明确时先说明。

提交前审查 working tree，只 stage 本任务明确路径，不使用 `git add .`/`-A`，不 force push，不重置其他人的修改。最终 PR 说明建议包含：

```text
基线与改动范围
环境与工具调用链：之前 → 之后
保留的治理/返工/封存不变量
配置迁移与 legacy 选择
测试：实际执行 / 未执行 / 原因
安全边界与不支持项
性能数据与残余风险
```

PR 中必须提供至少一次真实 Docker Provider 的代码与 Office 测试结果。能创建 Draft PR 不等于通过验收；若受执行环境限制无法完成集成验证，就保留 Draft 状态和明确未完成项，不编造“已通过”。

### 16.3 最终完成定义

任务完成，不是因为新增了一个 EnvironmentProvider 接口或一次 `docker run` 成功。必须同时满足：

**两个 Profile 的真实能力成立；全部文件与命令操作使用统一任务视图；多轮与返工的状态连续；环境故障不再消耗业务 Agent 长时间排障；成果通过原有治理链；取消清理与权限边界有实测证据；原有正确路径的回归通过；配置迁移与 PR 可审查。**

---

## 附录 A：给 Codex 的开工提示词

> 请在 Nephamaster/pi 的最新仓库上实施这份任务书，不要只返回设计建议，也不要只修 PPT。
>
> 开始前读取最新 AGENTS.md、相关源码和仓库状态，核对与审查基线 c650e51 的差异。先执行 M0，记录基线、调用链、复现与改动计划，再按 M1—M6 逐步编码、运行测试并形成提交。
>
> 目标是一个完整的 Docker/OCI 执行后端，统一 Pi 的文件、搜索、Bash、后台进程与成果导出。保留原有 Session、Workflow、批准、返工、模板和交付语义。不得只把 Bash 放进容器、其他路径仍访问宿主；不得自动降级、关闭防护、继承宿主秘密或删测试。
>
> 用真实 Provider 和合成业务 fixture 验证，不调用付费模型和生产系统。没有 Docker 或必要权限时清楚记录阻塞，不能以 mock/skip 声称集成通过。每阶段把已验证状态和剩余工作写入 Checkpoint/IPD-environment.md，恢复上下文后先读它。
>
> 在功能分支上提交本任务改动并发起 PR；只提交自己修改的文件，不改 main、不合并 PR。最终说明实际改动、保留行为、测试与限制。不要把新增接口等同于完成全部改造。

## 附录 B：资料与使用边界

本方案的已发现问题来自 `IPD-environment-review.md`（c650e51 审查）及本会话中的源码读取。该报告的六个隔离探针不是完整仓库、Docker 或真实模型运行证据。执行者必须重新转成真实测试。

实施时查阅以下官方资料的当前版本与实际安装版本，不复制未验证的 API：

```text
OpenHands Workspace / Agent Server（借鉴执行边界，不移植其整套 Agent）：
https://docs.openhands.dev/sdk/arch/workspace
https://docs.openhands.dev/sdk/guides/agent-server/overview

Docker 安全、rootless 资源限制与 seccomp：
https://docs.docker.com/engine/security/
https://docs.docker.com/engine/security/rootless/tips/
https://docs.docker.com/engine/security/seccomp/

Docker exec / pause / cp / 网络：
https://docs.docker.com/reference/cli/docker/container/exec/
https://docs.docker.com/reference/cli/docker/container/pause/
https://docs.docker.com/reference/cli/docker/container/cp/
https://docs.docker.com/reference/cli/docker/network/create/

Dev Container Specification（借鉴配方和预构建，不视为安全边界）：
https://containers.dev/overview
```

官方文档支持的是各组件的能力与边界；本文中 Profile、lease、里程碑、命名和接入方案是为本项目提出的工程设计，不应标为官方方案。
